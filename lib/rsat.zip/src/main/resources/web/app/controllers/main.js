"use strict"

app.controller('MainController', ['$globalSettings', function($globalSettings) {
	var ctrl = this;
}]);