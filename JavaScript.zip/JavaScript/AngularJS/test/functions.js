










/*











perm(symbols, splitArr.length, 0);
console.log(Math.pow(symbols.length, splitArr.length));
console.log(Math.pow(splitArr.length, symbols.length));
arr = perm(symbols, splitArr.length, 0);



function perm(symbols, positions, position) {
	var mass = [];
	var cnt = 0;
	for (var i = 0; i <= symbols.length - 1; i++) {
		var submass = [];
		for (var j = 0; j < positions; j++) {
			submass[j] = symbols[i]; 
		}
		mass[i] = submass;
	}

}


function permutations(symbols, maxPosition, position, arr) {
	if (position == 0 || position == undefined) {
		position = 0;
		for (z = 0; z <= maxPosition - 1; z++) {
			arr.push(symbols[0]);
		}
	}

	for (x = 0; x <= symbols.length - 1; x++) {
		arr[position] = symbols[x];
		console.log(arr);

		if ((position + 1) != maxPosition) {
			permutations(symbols, maxPosition, position + 1, arr);
		}
	}
}

*/

/*

var symbols = ['a','b', 'c', 'd'];
mask = '*';
text = 'https://yadi.sk/d/*doWu*3sWGy';

var splitArr = text.split(mask);
var arr = [];


var arr = [];
console.log('=================================');
console.log(' ' + requr(symbols, splitArr, 0, arr));
console.log('=================================');


function requr(symbols, splitArr, position, arr) {
	var mass = [], newArr = [];
	var str = '';
	if ((arr.length) == 0) {
		for (z = 0; z <= splitArr.length - 1; z++) {
			newArr.push('');
		}
		arr.push(newArr);
	}

	for (var i = 0; i <= symbols.length - 1; i++) {
		mass = arr[arr.length - 1];
		if (mass == "undefined") mass =[''];

		mass[position] = splitArr[position] + symbols[i];
		
		if ((position + 1) != splitArr.length) {
			arr = requr(symbols, splitArr, position + 1, arr);
		}

		str = '';
		for (var j = 0; j <= mass.length - 1; j++) {
			str += mass[j];
		}
		
		console.log(str);
		arr.push(mass);
	}

	return arr;
}









places = splitArr.length;

var getAllCombinations = function(symbols, places) {
   var result = symbols, counter = 0;
   
   if (places > 1)
      do {
         var subresult = [], counter = 0;
         for (var i = 0; i < result.length; i++)
            for (var j = 0; j < symbols.length; j++) {
               subresult[counter] = result[i] + symbols[j];
               counter++;
            }
         result = subresult;
      } while (result.length < Math.pow(symbols.length, places));
   return result;
};


var getAsArrayOfArrays = function(arr, length) {
   var result = [];
   for (var i = 0; i < arr.length; i++) {
      result[i] = [arr[i].charAt(0)];
      for (var j = 1; j < length; j++)
         result[i][j] = arr[i].charAt(j)
   }
   return result;
}

var result = getAllCombinations(symbols, places);
console.log(result);

result = getAsArrayOfArrays(result, places);

console.log(' ' + result);


	if (resultingArray.length <= 1) {
			if (resultingArray.length == 0) {
				resultingArray.push([charactersArray[0]]);
			} else {
				if (resultingArray[0].length < patternArray.length - 1) {
					resultingArray[0].push(charactersArray[0]);
				}
			}
		}

*/

var charactersArray = ['a','b'];
var mask = '*';
var pattern = 'https://yadi.sk/d/*doWu*3sWGy';
var generatedArray = [];

console.log(' ' + permutations(charactersArray, pattern.split(mask), 0, generatedArray));


function permutations(charactersArray, patternArray, position, resultingArray) {
	var startReqursion = false;

	for (var i = 0; i < charactersArray.length; i++) {
		if (resultingArray.length == 0) {
			resultingArray.push([charactersArray[0]]);
		} else {

			if (resultingArray[resultingArray.length - 1].length < patternArray.length - 1) {
				resultingArray[resultingArray.length - 1].push(charactersArray[0]);
			}
		}

		if ((position + 1) < patternArray.length - 1) {
			resultingArray = permutations(charactersArray, patternArray, position + 1, resultingArray);
			startReqursion = true;
		}

		if (startReqursion || (!startReqursion && i > 0)) {
			resultingArray.push(resultingArray[resultingArray.length - 1].slice());
			resultingArray[resultingArray.length - 2] = resultingArray[resultingArray.length - 2].join();
		}
		
		resultingArray[resultingArray.length - 1][position] = charactersArray[i];
	}
	return resultingArray;
}
