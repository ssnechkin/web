<?php
/**
 * This example shows sending a message using a local sendmail binary.
 */

require 'PHPMailerAutoload.php';


$mail = new PHPMailer;//Create a new PHPMailer instance

$mail->isSendmail();// Set PHPMailer to use the sendmail transport

$mail->setFrom('snechkinu@gmail.com', 'First Last');//Set who the message is to be sent from

$mail->addReplyTo('snechkinu@gmail.com', 'First Last');//Set an alternative reply-to address

$mail->addAddress('snechkinu@gmail.com', 'John Doe');//Set who the message is to be sent to

$mail->Subject = 'PHPMailer sendmail test';//Set the subject line

//$mail->msgHTML(file_get_contents('contents.html'), dirname(__FILE__));//Read an HTML message body from an external file, convert referenced images to embedded, convert HTML into a basic plain-text alternative body

$mail->AltBody = 'This is a plain-text message body';//Replace the plain text body with one created manually

$mail->msgHTML("file_get_contents('contents.html'), dirname(__FILE__)");//Attach an html file

$mail->addAttachment('images/phpmailer_mini.png');//Attach an image file



//send the message, check for errors
if (!$mail->send()) {
    echo "Mailer Error: " . $mail->ErrorInfo;
} else {
    echo "Message sent!";
}