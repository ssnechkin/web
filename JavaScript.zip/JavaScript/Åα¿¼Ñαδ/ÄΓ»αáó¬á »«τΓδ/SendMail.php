<?php

class SendMailSmtp {

 	public function __construct() {
 		$this->secureSocketsType 	= "ssl";					// Тип безопасности соединения ssl/tls
		$this->smtpServerHost	 	= "smtp.yandex.ru";			// адрес SMTP сервера
		$this->smtpServerName	 	= "yandex.ru";				// адрес SMTP сервера
		$this->port 			 	= 465;						// порт SMTP сервера		
		$this->loginInServer	 	= "sitemailname";			// Логин на существующий почтовый ящик на сервере
		$this->passwordInServer	 	= "site_mail_password";		// Логин на существующий почтовый ящик на сервере
		$this->mailAdressInServer	= "sitemailname@yandex.ru";	// Почтовый адрес на существующий почтовый ящик на сервере
		
		$this->messageDate			= date("D, j M Y G:i:s");	// Дата отправки сообщения
		$this->senderName			= "Отправитель";			// Имя отправителя
		$this->senderEmail			= "login@mail.ru"; 			// почта отправителя
		$this->reSenderName			= "Отправитель";			// Имя кому отправить ответ
		$this->reSenderEmail		= "login@mail.ru"; 			// почта кому отправить ответ
		$this->recipientName		= "Имя получателя"; 		// Имя получателя
		$this->recipientEmail		= "snechkinu@gmail.com"; 	// почта получателя
		$this->mailTo 			 	= "snechkinu@gmail.com";	// Кому отправить письмо
		$this->subject 			 	= "Тема письма";			// Тема письма
		$this->bodyMessage 			= "";						// Тело сообщения
		$this->charset 				= "utf-8";					// Кодировка сообщений
		
        $this->header  = "Date: ".$this->messageDate."\r\n";
		//$this->header .= "From: =?".$this->charset."?Q?".str_replace("+","_",str_replace("%","=",urlencode($this->senderName)))."?= <".$this->senderEmail.">\r\n";
		$this->header .= "From: \"".$this->senderName."\" <".$this->senderEmail.">";
		$this->header .= "Reply-To: =?".$this->charset."?Q?".str_replace("+","_",str_replace("%","=",urlencode($this->reSenderName)))."?= <".$this->reSenderEmail.">\r\n";
		$this->header .= "X-Priority: 3 (Normal)\r\n";
		$this->header .= "Message-ID: <172562218.".date("YmjHis")."@mail.ru>\r\n";
		$this->header .= "To: =?".$this->charset."?Q?".str_replace("+","_",str_replace("%","=",urlencode($this->recipientName)))."?= <".$this->recipientEmail.">\r\n";
		$this->header .= "Subject: =?".$this->charset."?Q?".str_replace("+","_",str_replace("%","=",urlencode($this->subject)))."?=\r\n";
		$this->header .= "MIME-Version: 1.0\r\n";
		$this->header .= "Content-Type: multipart/mixed; boundary=\"----------A4D921C2D10D7DB\"\r\n";
		$this->header .= "\r\n";
    }

    public function resetHeader() {
    	$this->header  = "Date: ".$this->messageDate."\r\n";		
		$this->header .= "From: \"".$this->senderName."\" <".$this->senderEmail.">";
		$this->header .= "Reply-To: =?".$this->charset."?Q?".str_replace("+","_",str_replace("%","=",urlencode($this->reSenderName)))."?= <".$this->reSenderEmail.">\r\n";
		$this->header .= "X-Priority: 3 (Normal)\r\n";
		$this->header .= "Message-ID: <172562218.".date("YmjHis")."@mail.ru>\r\n";
		$this->header .= "To: =?".$this->charset."?Q?".str_replace("+","_",str_replace("%","=",urlencode($this->recipientName)))."?= <".$this->recipientEmail.">\r\n";
		$this->header .= "Subject: =?".$this->charset."?Q?".str_replace("+","_",str_replace("%","=",urlencode($this->subject)))."?=\r\n";
		$this->header .= "MIME-Version: 1.0\r\n";
		$this->header .= "Content-Type: multipart/mixed; boundary=\"----------A4D921C2D10D7DB\"\r\n";
		$this->header .= "\r\n";
    }

    public function setSecureSocketsType($newValue) { $this->secureSocketsType  = $newValue; }
	public function setSmtpServerHost($newValue) { $this->smtpServerHost= $newValue; }
	public function setSmtpServerName($newValue) { $this->smtpServerName= $newValue; }
	public function setPort ($newValue) { $this->port= $newValue; }
	public function setLoginInServer($newValue) { $this->loginInServer = $newValue; }
	public function setPasswordInServer ($newValue) { $this->passwordInServer= $newValue; }
	public function setMailAdressInServer($newValue) { $this->mailAdressInServer  = $newValue; }
	public function setMessageDate($newValue) { $this->messageDate  = $newValue; }
	public function setSenderName ($newValue) { $this->senderName= $newValue; }
	public function setSenderEmail($newValue) { $this->senderEmail  = $newValue; }
	public function setReSenderName($newValue) { $this->reSenderName  = $newValue; }
	public function setReSenderEmail($newValue) { $this->reSenderEmail = $newValue; }
	public function setRecipientName($newValue) { $this->recipientName = $newValue; }
	public function setRecipientEmail($newValue) { $this->recipientEmail= $newValue; }
	public function setMailTo($newValue) { $this->mailTo  = $newValue; }
	public function setSubject($newValue) { $this->subject = $newValue; }
	public function setHeader($newValue) { $this->header  = $newValue; }
	public function setBodyMessage($newValue) { $this->bodyMessage  = $newValue; }
	public function setCharset($newValue) { $this->charset  = $newValue; }
	public function setParameters($parameters) {
		if ( is_array($parameters) ){
			$this->secureSocketsType=isset($parameters['secureSocketsType'])?$parameters['secureSocketsType']:$this->secureSocketsType;
			$this->smtpServerHost=isset($parameters['smtpServerHost'])?$parameters['smtpServerHost']:$this->smtpServerHost;
			$this->smtpServerName=isset($parameters['smtpServerName'])?$parameters['smtpServerName']:$this->smtpServerName;
			$this->port=isset($parameters['port'])?$parameters['port']:$this->port;
			$this->loginInServer=isset($parameters['loginInServer'])?$parameters['loginInServer']:$this->loginInServer;
			$this->passwordInServer=isset($parameters['passwordInServer'])?$parameters['passwordInServer']:$this->passwordInServer;
			$this->mailAdressInServer=isset($parameters['mailAdressInServer'])?$parameters['mailAdressInServer']:$this->mailAdressInServer;
			$this->messageDate=isset($parameters['messageDate'])?$parameters['messageDate']:$this->messageDate;
			$this->senderName=isset($parameters['senderName'])?$parameters['senderName']:$this->senderName;
			$this->senderEmail=isset($parameters['senderEmail'])?$parameters['senderEmail']:$this->senderEmail;
			$this->reSenderName=isset($parameters['reSenderName'])?$parameters['reSenderName']:$this->reSenderName;
			$this->reSenderEmail=isset($parameters['reSenderEmail'])?$parameters['reSenderEmail']:$this->reSenderEmail;
			$this->recipientName=isset($parameters['recipientName'])?$parameters['recipientName']:$this->recipientName;
			$this->recipientEmail=isset($parameters['recipientEmail'])?$parameters['recipientEmail']:$this->recipientEmail;
			$this->mailTo=isset($parameters['mailTo'])?$parameters['mailTo']:$this->mailTo;
			$this->subject=isset($parameters['subject'])?$parameters['subject']:$this->subject;
			$this->header=isset($parameters['header'])?$parameters['header']:$this->header;
			$this->bodyMessage=isset($parameters['bodyMessage'])?$parameters['bodyMessage']:$this->bodyMessage;
			$this->charset=isset($parameters['charset'])?$parameters['charset']:$this->charset;
		}
	}

	public function getSecureSocketsType() { return $this->secureSocketsType; }
	public function getSmtpServerHost() { return $this->smtpServerHost; }
	public function getSmtpServerName() { return $this->smtpServerName; }
	public function getPort() { return $this->port; }
	public function getLoginInServer() { return $this->loginInServer; }
	public function getPasswordInServer() { return $this->passwordInServer; }
	public function getMailAdressInServer() { return $this->mailAdressInServer; }
	public function getMessageDate() { return $this->messageDate; }
	public function getSenderName() { return $this->senderName; }
	public function getSenderEmail() { return $this->senderEmail; }
	public function getReSenderName() { return $this->reSenderName; }
	public function getReSenderEmail() { return $this->reSenderEmail; }
	public function getRecipientName() { return $this->recipientName; }
	public function getRecipientEmail() { return $this->recipientEmail; }
	public function getMailTo() { return $this->mailTo; }
	public function getSubject() { return $this->subject; }
	public function getHeader() { return $this->header; }
	public function getBodyMessage() { return $this->bodyMessage; }
	public function charset() { return $this->charset; }
    public function getParameters() {
		return array(
			 "secureSocketsType" => $this->secureSocketsType
			,"smtpServerHost" => $this->smtpServerHost
			,"smtpServerName" => $this->smtpServerName
			,"port" => $this->port	
			,"loginInServer" => $this->loginInServer
			,"passwordInServer" => $this->passwordInServer
			,"mailAdressInServer" => $this->mailAdressInServer			
			,"messageDate" => $this->messageDate
			,"senderName" => $this->senderName
			,"senderEmail" => $this->senderEmail
			,"reSenderName" => $this->reSenderName
			,"reSenderEmail" => $this->reSenderEmail
			,"recipientName" => $this->recipientName
			,"recipientEmail" => $this->recipientEmail
			,"mailTo" => $this->mailTo
			,"subject" => $this->subject
			,"header" => $this->header
			,"bodyMessage" => $this->bodyMessage
			,"charset" => $this->charset
		);
    }

    public function addFile($pthFile) {
		$this->bodyMessage .= "------------A4D921C2D10D7DB\r\n";
		$this->bodyMessage .= "Content-Type: application/octet-stream; name=\"1.jpg\"\r\n";
		$this->bodyMessage .= "Content-transfer-encoding: base64\r\n";
		$this->bodyMessage .= "Content-Disposition: attachment; filename=\"1.jpg\"\r\n";
		$fp = fopen($pthFile, "rb");
		$this->bodyMessage .= "\r\n".chunk_split(base64_encode(fread($fp, filesize($pthFile))))."\r\n";
		fclose($fp);
    }

    public function addTextAsFile($text) {
		$this->bodyMessage .= "------------A4D921C2D10D7DB\r\n";
		$this->bodyMessage .= "Content-Type: application/octet-stream; name=\"2.txt\"\r\n";
		$this->bodyMessage .= "Content-transfer-encoding: base64\r\n";
		$this->bodyMessage .= "Content-Disposition: attachment; filename=\"2.txt\"\r\n";
		$this->bodyMessage .= "\r\n".base64_encode($text)."\r\n";
    }

    public function addText($text) {
		$this->bodyMessage .= "------------A4D921C2D10D7DB\r\n";
		$this->bodyMessage .= "Content-Type: text/plain; charset=".$this->charset."\r\n";
		$this->bodyMessage .= "Content-Transfer-Encoding: 8bit\r\n";
		$this->bodyMessage .= "\r\n".$text."\r\n";
    }

	public function send() {
		$protocol = array(
			  array( 220, $this->secureSocketsType . "://" . $this->smtpServerHost )
			, array( 250, "HELO " . $this->smtpServerName . "\r\n" )
			, array( 334, "AUTH LOGIN\r\n" )
			, array( 334, base64_encode( $this->loginInServer ) . "\r\n" )
			, array( 235, base64_encode( $this->passwordInServer ) . "\r\n" )
			, array( 250, "MAIL FROM:" . $this->mailAdressInServer . "\r\n" )
			, array( 250, "RCPT TO:" . $this->mailTo . "\r\n" )
			, array( 354, "DATA \r\n" )
			, array( 250, $this->header . $this->bodyMessage . "\r\n.\r\n" )
			, array( 221, "QUIT\r\n" )
		);

		try {
			$i = 0;	$log = "";
			foreach( $protocol as $arr ) {	
				$i++;
				
				if ($i == 1) {	$smtp_conn = fsockopen( $arr[1], $this->port, $errno, $errstr, 10 );
					if (!$smtp_conn) { return "ERROR:".$errno." - ".$errstr; }
				} else { fputs( $smtp_conn, $arr[1] ); }

				$data = "";
				while($str = fgets($smtp_conn, 515)) {
					$log  .= "<br />" .$arr[1]." => ". $str;
					$data .= $str;
					if(substr($str, 3, 1) == " ") { break; }
				}

				if (substr($data,0,3) != $arr[0]) { fclose($smtp_conn); return $log; }
			}
		} catch (Exception $e) {            
            return  $e->getMessage();
        }
        fclose($smtp_conn);
        return true;
    }

    public function sendFromLocalServer() {
		$protocol = array(
			  array( 220, $_SERVER["SERVER_ADDR"] )
			, array( 250, "HELO " . $_SERVER["SERVER_NAME"] . "\r\n" )
			, array( 334, "AUTH LOGIN\r\n" )
			, array( 334, base64_encode( "shugar" ) . "\r\n" )
			, array( 235, base64_encode( "1" ) . "\r\n" )
			, array( 250, "MAIL FROM:" . $this->mailAdressInServer . "\r\n" )
			, array( 250, "RCPT TO:" . $this->mailTo . "\r\n" )
			, array( 354, "DATA \r\n" )
			, array( 250, $this->header . $this->bodyMessage . "\r\n.\r\n" )
			, array( 221, "QUIT\r\n" )
		);

		try {
			$i = 0;	$log = "";
			foreach( $protocol as $arr ) {	
				$i++;
				
				if ($i == 1) {	$smtp_conn = fsockopen( $arr[1], $this->port, $errno, $errstr, 10 );
					if (!$smtp_conn) { return "ERROR:".$errno." - ".$errstr; }
				} else { fputs( $smtp_conn, $arr[1] ); }

				$data = "";
				while($str = fgets($smtp_conn, 515)) {
					$log  .= "<br />" .$arr[1]." => ". $str;
					$data .= $str;
					if(substr($str, 3, 1) == " ") { break; }
				}

				if (substr($data,0,3) != $arr[0]) { fclose($smtp_conn); return $log; }
			}
		} catch (Exception $e) {            
            return  $e->getMessage();
        }
        fclose($smtp_conn);
        return true;
    }
}



$mailer = new SendMailSmtp();
$mailer->setParameters(array(
	  'smtpServerName' 		=> 'mail.ru'
	, 'smtpServerHost' 		=> 'smtp.mail.ru'
	, 'mailAdressInServer'	=> 'sitemailname@mail.ru'
	, 'loginInServer'		=> 'sitemailname'
	, 'passwordInServer'	=> 'site_mail_password'
, 'mailTo'				=> 'nclient@yandex.ru'
		));
$mailer->addText("Текст1 сообщения");

$mailer->resetHeader();
print_r( $mailer->send() );
//print_r( $mailer->getHeader() );












//$mailer->addFile("1.jpg");
//$mailer->addTextAsFile("Текст сообщения в файле");
//$mailer->addText("Текст1 сообщения");
//$mailer->addText("Текст2 сообщения");
//$mailer->addText("Текст3 сообщения");
//print_r( ) );
//print_r( $mailer->getParameters() );
//print_r( $mailer->getSecureSocketsType() );
//print_r( $mailer->send() );


//$mailer->getLocalSmtpServer();
//echo exec('hostname');
//echo $_SERVER["SERVER_NAME"];

/*
$this->secureSocketsType 	= "ssl";					// Тип безопасности соединения ssl/tls
		$this->smtpServerHost	 	= "smtp.yandex.ru";			// адрес SMTP сервера
		$this->smtpServerName	 	= "yandex.ru";				// адрес SMTP сервера
		$this->port 			 	= 465;						// порт SMTP сервера		
		$this->loginInServer	 	= "sitemailname";			// Логин на существующий почтовый ящик на сервере
		$this->passwordInServer	 	= "site_mail_password";		// Логин на существующий почтовый ящик на сервере
		$this->mailAdressInServer	= "sitemailname@yandex.ru";	// Почтовый адрес на существующий почтовый ящик на сервере
		
		$this->messageDate			= date("D, j M Y G:i:s");	// Дата отправки сообщения
		$this->senderName			= "Отправитель";			// Имя отправителя
		$this->senderEmail			= "login@mail.ru"; 			// почта отправителя
		$this->reSenderName			= "Отправитель";			// Имя кому отправить ответ
		$this->reSenderEmail		= "login@mail.ru"; 			// почта кому отправить ответ
		$this->recipientName		= "Имя получателя"; 		// Имя получателя
		$this->recipientEmail		= "snechkinu@gmail.com"; 	// почта получателя
		$this->mailTo 			 	= "snechkinu@gmail.com";	// Кому отправить письмо
		$this->subject 			 	= "Тема письма";			// Тема письма
		$this->bodyMessage 			= "";						// Тело сообщения
		$this->charset 				= "utf-8";					// Кодировка сообщений
		
        $this->header  = "Date: ".$this->messageDate."\r\n";
		$this->header .= "From: =?".$this->charset."?Q?".str_replace("+","_",str_replace("%","=",urlencode($this->senderName)))."?= <".$this->senderEmail.">\r\n"; 
		$this->header .= "Reply-To: =?".$this->charset."?Q?".str_replace("+","_",str_replace("%","=",urlencode($this->reSenderName)))."?= <".$this->reSenderEmail.">\r\n";
		$this->header .= "X-Priority: 3 (Normal)\r\n";
		$this->header .= "Message-ID: <172562218.".date("YmjHis")."@mail.ru>\r\n";
		$this->header .= "To: =?".$this->charset."?Q?".str_replace("+","_",str_replace("%","=",urlencode($this->recipientName)))."?= <".$this->recipientEmail.">\r\n";
		$this->header .= "Subject: =?".$this->charset."?Q?".str_replace("+","_",str_replace("%","=",urlencode($this->subject)))."?=\r\n";
		$this->header .= "MIME-Version: 1.0\r\n";
		$this->header .= "Content-Type: multipart/mixed; boundary=\"----------A4D921C2D10D7DB\"\r\n";
		$this->header .= "\r\n";
	function send($mailTo, $subject, $message, $headers) {
        $contentMail = "Date: " . date("D, d M Y H:i:s") . " UT\r\n";
        $contentMail .= 'Subject: =?' . $this->smtp_charset . '?B?'  . base64_encode($subject) . "=?=\r\n";
        $contentMail .= $headers . "\r\n";
        $contentMail .= $message . "\r\n";
        
        try {
            if(!$socket = @fsockopen($this->smtp_host, $this->smtp_port, $errorNumber, $errorDescription, 30)){
                throw new Exception($errorNumber.".".$errorDescription);
            }
            if (!$this->_parseServer($socket, "220")){
                throw new Exception('Connection error');
            }
			
			$server_name = $_SERVER["SERVER_NAME"];
            fputs($socket, "HELO $server_name\r\n");
            if (!$this->_parseServer($socket, "250")) {
                fclose($socket);
                throw new Exception('Error of command sending: HELO');
            }
            
            fputs($socket, "AUTH LOGIN\r\n");
            if (!$this->_parseServer($socket, "334")) {
                fclose($socket);
                throw new Exception('Autorization error');
            }			
			
            
            fputs($socket, base64_encode($this->smtp_username) . "\r\n");
            if (!$this->_parseServer($socket, "334")) {
                fclose($socket);
                throw new Exception('Autorization error');
            }
            
            fputs($socket, base64_encode($this->smtp_password) . "\r\n");
            if (!$this->_parseServer($socket, "235")) {
                fclose($socket);
                throw new Exception('Autorization error');
            }
			
            fputs($socket, "MAIL FROM: <".$this->smtp_username.">\r\n");
            if (!$this->_parseServer($socket, "250")) {
                fclose($socket);
                throw new Exception('Error of command sending: MAIL FROM');
            }
            
			$mailTo = ltrim($mailTo, '<');
			$mailTo = rtrim($mailTo, '>');
            fputs($socket, "RCPT TO: <" . $mailTo . ">\r\n");     
            if (!$this->_parseServer($socket, "250")) {
                fclose($socket);
                throw new Exception('Error of command sending: RCPT TO');
            }
            
            fputs($socket, "DATA\r\n");     
            if (!$this->_parseServer($socket, "354")) {
                fclose($socket);
                throw new Exception('Error of command sending: DATA');
            }
            
            fputs($socket, $contentMail."\r\n.\r\n");
            if (!$this->_parseServer($socket, "250")) {
                fclose($socket);
                throw new Exception("E-mail didn't sent");
            }
            
            fputs($socket, "QUIT\r\n");
            fclose($socket);
        } catch (Exception $e) {
            return  $e->getMessage();
        }
        return true;
    }

    [test-msa24.rhcloud.com 56af4de40c1e66e9b1000245]\> dig rhcloud.com
dig: isc_socket_bind: permission denied
[test-msa24.rhcloud.com 56af4de40c1e66e9b1000245]\> ^C
[test-msa24.rhcloud.com 56af4de40c1e66e9b1000245]\>
[test-msa24.rhcloud.com 56af4de40c1e66e9b1000245]\>
[test-msa24.rhcloud.com 56af4de40c1e66e9b1000245]\> nslookup
> set type=MX
> rhcloud.com
nslookup: isc_socket_bind: permission denied
[test-msa24.rhcloud.com 56af4de40c1e66e9b1000245]\> telnet
telnet> quit
[test-msa24.rhcloud.com 56af4de40c1e66e9b1000245]\> telnet rhcloud.com 25
Trying 54.174.51.64...
^C
[test-msa24.rhcloud.com 56af4de40c1e66e9b1000245]\> telnet 52.90.146.235 25
Trying 52.90.146.235...
Connected to 52.90.146.235.
Escape character is '^]'.
220 use-mailrelay1.prod.rhcloud.com ESMTP
quit
221 2.0.0 Bye
Connection closed by foreign host.
[test-msa24.rhcloud.com 56af4de40c1e66e9b1000245]\>

*/
?>