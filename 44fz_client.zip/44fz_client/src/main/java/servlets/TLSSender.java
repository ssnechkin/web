package servlets;

import utils.GostTLS;

import javax.net.ssl.*;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.net.URL;
import java.security.*;
import java.security.cert.Certificate;
import java.security.cert.X509Certificate;

public class TLSSender extends HttpServlet {
    @Override
    public void init() {
        // System.out.println("init");
    }

    private GostTLS gostTLS;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String result = "server null";

        try {

            if (gostTLS == null)
                gostTLS = new GostTLS("44-fz", "changeit".toCharArray(),
                        "certs.jks", "changeit".toCharArray());
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>");
            stringBuilder.append("<Package xmlns=\"http://www.sberbank.ru/edo/oep/edo-oep-document\">");
            stringBuilder.append("<TypeDocument>PartyCheckRs</TypeDocument>");
            stringBuilder.append("<Document>PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0idXRmLTgiIHN0YW5kYWxvbmU9InllcyI/Pgo8UGFydHlDaGVja1JzIHhtbG5zPSJodHRwOi8vd3d3LnNiZXJiYW5rLnJ1L2Vkby9vZXAvZWRvLW9lcC1wcm9jIj4KICA8TXNnSUQ+NzcwNEM3MDVDNUZFMDg5N0UwNTMzRkZDNTIwQThFNjI8L01zZ0lEPgogIDxNc2dUbT4yMDE4LTA5LTI5VDE3OjU2OjMxPC9Nc2dUbT4KICA8Q29ycmVsYXRpb25JRD40Y2I4ZWM0Y2U1NmE0MjdmOTUwOTRjOGFhNjBhNTJjOTwvQ29ycmVsYXRpb25JRD4KICA8T3BlcmF0b3JOYW1lPkVUUF9SVFM8L09wZXJhdG9yTmFtZT4KICA8QmFua0lEPlJOS0I8L0JhbmtJRD4KICA8SU5OPjUxMTQ5MDY1NzQ8L0lOTj4KICA8S1BQPjg4OTgxMDIwMTwvS1BQPgogIDxPR1JOPjk1Njg4MTM1MTY1MzE8L09HUk4+CiAgPFN0YXR1cz48U3RhdHVzQ29kZT4yPC9TdGF0dXNDb2RlPjxTdGF0dXNEZXNjPtCX0LDQv9GA0L7RgSDQvdC1INCy0YvQv9C+0LvQvdC10L0sINGB0YfQtdGCINC+0YLRgdGD0YLRgdGC0LLRg9C10YI8L1N0YXR1c0Rlc2M+PC9TdGF0dXM+CjwvUGFydHlDaGVja1JzPg==</Document>");
            stringBuilder.append("<Signature>MIAGCSqGSIb3DQEHAqCAMIACAQExDDAKBgYqhQMCAgkFADCABgkqhkiG9w0BBwEAAKCAMIIIATCCB7CgAwIBAgIRAQUgqXrEDNGA6BGvwJa3HA8wCAYGKoUDAgIDMIIBbDEYMBYGBSqFA2QBEg0xMDI3NzAwMDcxNTMwMRowGAYIKoUDA4EDAQESDDAwNzcwNDIxMTIwMTELMAkGA1UEBhMCUlUxGDAWBgNVBAgMDzc3INCc0L7RgdC60LLQsDEVMBMGA1UEBwwM0JzQvtGB0LrQstCwMTkwNwYDVQQJDDDQkdCw0YDRi9C60L7QstGB0LrQuNC5INC/0LXRgC4sINC0LiA0LCDRgdGC0YAuIDIxMDAuBgNVBAsMJ9Cj0LTQvtGB0YLQvtCy0LXRgNGP0Y7RidC40Lkg0YbQtdC90YLRgDFnMGUGA1UECgxe0J7QsdGJ0LXRgdGC0LLQviDRgSDQvtCz0YDQsNC90LjRh9C10L3QvdC+0Lkg0L7RgtCy0LXRgtGB0YLQstC10L3QvdC+0YHRgtGM0Y4gItCi0LDQutGB0LrQvtC8IjEgMB4GA1UEAwwX0J7QntCeICLQotCw0LrRgdC60L7QvCIwHhcNMTgwOTI1MTAyODAwWhcNMTkwOTI1MTAzODAwWjCCATsxGjAYBggqhQMDgQMBARIMMDA3NzAxMTA1NDYwMRgwFgYFKoUDZAESDTEwMjc3MDAzODEyOTAxIzAhBgNVBAoMGtCg0J3QmtCRINCR0JDQndCaICjQn9CQ0J4pMVUwUwYDVQQJDEzQo9Cb0JjQptCQINCd0JDQkdCV0KDQldCW0J3QkNCvINCY0JzQldCd0JggNjAt0JvQldCi0JjQryDQodCh0KHQoCwg0JTQntCcIDM0MSowKAYDVQQHDCHQk9Ce0KDQntCUINCh0JjQnNCk0JXQoNCe0J/QntCb0KwxKTAnBgNVBAgMIDkxINCg0LXRgdC/0YPQsdC70LjQutCwINCa0YDRi9C8MQswCQYDVQQGEwJSVTEjMCEGA1UEAwwa0KDQndCa0JEg0JHQkNCd0JogKNCf0JDQnikwYzAcBgYqhQMCAhMwEgYHKoUDAgIkAAYHKoUDAgIeAQNDAARAWCEC1hJ1u4juAGOZ96B8inyQ9P17wfn3yLt9H7sIZeUkYJroVMmwlJGL0rdYQh82xTXYMHpeaaXtbMP627hEHqOCBFYwggRSMDQGCSsGAQQBgjcVBwQnMCUGHSqFAwICMgEJgdWRAYPDxk+F1ZU0g+ePBoOyB8wYAgEBAgEAMIIBhQYDVR0jBIIBfDCCAXiAFMLYIvy8D/3IrEBi5x/IszCf2ja7oYIBUqSCAU4wggFKMR4wHAYJKoZIhvcNAQkBFg9kaXRAbWluc3Z5YXoucnUxCzAJBgNVBAYTAlJVMRwwGgYDVQQIDBM3NyDQsy4g0JzQvtGB0LrQstCwMRUwEwYDVQQHDAzQnNC+0YHQutCy0LAxPzA9BgNVBAkMNjEyNTM3NSDQsy4g0JzQvtGB0LrQstCwLCDRg9C7LiDQotCy0LXRgNGB0LrQsNGPLCDQtC4gNzEsMCoGA1UECgwj0JzQuNC90LrQvtC80YHQstGP0LfRjCDQoNC+0YHRgdC40LgxGDAWBgUqhQNkARINMTA0NzcwMjAyNjcwMTEaMBgGCCqFAwOBAwEBEgwwMDc3MTA0NzQzNzUxQTA/BgNVBAMMONCT0L7Qu9C+0LLQvdC+0Lkg0YPQtNC+0YHRgtC+0LLQtdGA0Y/RjtGJ0LjQuSDRhtC10L3RgtGAggo9vVUJAAAAAAI8MB0GA1UdDgQWBBQ4cJGaapAK5xB08hsvg3cnTb5fljAOBgNVHQ8BAf8EBAMCA/gwHQYDVR0lBBYwFAYIKwYBBQUHAwIGCCsGAQUFBwMEMB0GA1UdIAQWMBQwCAYGKoUDZHEBMAgGBiqFA2RxAjCCARQGBSqFA2RwBIIBCTCCAQUMKyLQmtGA0LjQv9GC0L7Qn9GA0L4gQ1NQIiAo0LLQtdGA0YHQuNGPIDQuMCkMLCLQmtGA0LjQv9GC0L7Qn9GA0L4g0KPQpiIgKNCy0LXRgNGB0LjRjyAyLjApDFfQodC10YDRgtC40YTQuNC60LDRgiDRgdC+0L7RgtCy0LXRgtGB0YLQstC40Y8g0KHQpC8xMjQtMjg2NCDQvtGCIDIwINC80LDRgNGC0LAgMjAxNiDQsy4MT9Ch0LXRgNGC0LjRhNC40LrQsNGCINGB0L7QvtGC0LLQtdGC0YHRgtCy0LjRjyDQodCkLzEyOC0yOTgzINC+0YIgMTguMTEuMjAxNiDQsy4wIwYFKoUDZG8EGgwYItCa0YDQuNC/0YLQvtCf0YDQviBDU1AiMFIGA1UdHwRLMEkwR6BFoEOGQWh0dHA6Ly9jcmwudGF4Y29tLnJ1L2MyZDgyMmZjYmMwZmZkYzhhYzQwNjJlNzFmYzhiMzMwOWZkYTM2YmIuY3JsMIGSBggrBgEFBQcBAQSBhTCBgjAxBggrBgEFBQcwAYYlaHR0cDovL29jc3AyMC50YXhjb20ucnUvb2NzcC9vY3NwLnNyZjBNBggrBgEFBQcwAoZBaHR0cDovL2NybC50YXhjb20ucnUvYzJkODIyZmNiYzBmZmRjOGFjNDA2MmU3MWZjOGIzMzA5ZmRhMzZiYi5jcnQwCAYGKoUDAgIDA0EAIB7E6gxLoBdaoJ1PvgsTUFoMPov8/lfjA2yfodOPJZnfDSQZGGdYjZHvGJsb5SDfJ7OA6ukzgObsHuaItQwJCQAAMYIEETCCBA0CAQEwggGDMIIBbDEYMBYGBSqFA2QBEg0xMDI3NzAwMDcxNTMwMRowGAYIKoUDA4EDAQESDDAwNzcwNDIxMTIwMTELMAkGA1UEBhMCUlUxGDAWBgNVBAgMDzc3INCc0L7RgdC60LLQsDEVMBMGA1UEBwwM0JzQvtGB0LrQstCwMTkwNwYDVQQJDDDQkdCw0YDRi9C60L7QstGB0LrQuNC5INC/0LXRgC4sINC0LiA0LCDRgdGC0YAuIDIxMDAuBgNVBAsMJ9Cj0LTQvtGB0YLQvtCy0LXRgNGP0Y7RidC40Lkg0YbQtdC90YLRgDFnMGUGA1UECgxe0J7QsdGJ0LXRgdGC0LLQviDRgSDQvtCz0YDQsNC90LjRh9C10L3QvdC+0Lkg0L7RgtCy0LXRgtGB0YLQstC10L3QvdC+0YHRgtGM0Y4gItCi0LDQutGB0LrQvtC8IjEgMB4GA1UEAwwX0J7QntCeICLQotCw0LrRgdC60L7QvCICEQEFIKl6xAzRgOgRr8CWtxwPMAoGBiqFAwICCQUAoIICJzAYBgkqhkiG9w0BCQMxCwYJKoZIhvcNAQcBMC8GCSqGSIb3DQEJBDEiBCCrXAP5lgOHb2E24Dms0Zs8m39qPffLXhw8yvmQ1apGNTCCAdgGCyqGSIb3DQEJEAIvMYIBxzCCAcMwggG/MIIBuzAIBgYqhQMCAgkEIHo3ae54/PrPEm2dmRYAuNFf1TCO6ct3Jm9rKCrLwXOKMIIBizCCAXSkggFwMIIBbDEYMBYGBSqFA2QBEg0xMDI3NzAwMDcxNTMwMRowGAYIKoUDA4EDAQESDDAwNzcwNDIxMTIwMTELMAkGA1UEBhMCUlUxGDAWBgNVBAgMDzc3INCc0L7RgdC60LLQsDEVMBMGA1UEBwwM0JzQvtGB0LrQstCwMTkwNwYDVQQJDDDQkdCw0YDRi9C60L7QstGB0LrQuNC5INC/0LXRgC4sINC0LiA0LCDRgdGC0YAuIDIxMDAuBgNVBAsMJ9Cj0LTQvtGB0YLQvtCy0LXRgNGP0Y7RidC40Lkg0YbQtdC90YLRgDFnMGUGA1UECgxe0J7QsdGJ0LXRgdGC0LLQviDRgSDQvtCz0YDQsNC90LjRh9C10L3QvdC+0Lkg0L7RgtCy0LXRgtGB0YLQstC10L3QvdC+0YHRgtGM0Y4gItCi0LDQutGB0LrQvtC8IjEgMB4GA1UEAwwX0J7QntCeICLQotCw0LrRgdC60L7QvCICEQEFIKl6xAzRgOgRr8CWtxwPMAgGBiqFAwICEwRADwCLWfUwegoYGD5n6/8RoMm71xyiHn4JyIQru/dyEOmVodaWwN2+vpD6yCOnvDhPoVwmdtUyyk96RZnR/FrdAQAAAAAAAA==</Signature>");
            stringBuilder.append("</Package>");

            result = gostTLS.sendMessage("https://44fz.rncb.ru/", stringBuilder.toString().getBytes("UTF-8"));
            //result = gostTLS.sendMessage("https://bxtls.sberbank-ast.ru:9943", stringBuilder.toString().getBytes("UTF-8"));

            //result = gostTLS.sendMessage("https://zakaz3.zakazrf.ru:9443/BankTransport/ImportDocument?BankCode=RNKB", stringBuilder.toString().getBytes("UTF-8"));

            //result = gostTLS.sendMessage("https://stage-banki.tektorg.ru:10443/callback", stringBuilder.toString().getBytes("UTF-8"));
            /*System.setProperty("com.sun.security.enableCRLDP", "true");
            System.setProperty("com.ibm.security.enableCRLDP", "true");
            result = send("https://zakaz3.zakazrf.ru:9443/BankTransport/ImportDocument?BankCode=RNKB", getSSLContext().getSocketFactory());*/
            //result = send("https://stage-banki.tektorg.ru:10443/callback", getSSLContext().getSocketFactory());
        } catch (Exception e) {
            e.printStackTrace();
        }

        response.setContentType("text/html;charset=utf-8");
        response.setStatus(HttpServletResponse.SC_OK);
        response.getWriter().println("<h1>" + result + "</h1>");
    }
/*
    public SSLContext getSSLContext() throws Exception {
        String storeAlgorithm = "GostX509";
        String contextAlgorithm = "GostTLS"; //Provider.ALGORITHM
        char[] tlsPassword = "changeit".toCharArray();
        String tlsHDImageStoreAlias = "44-fz";

        KeyStore keyStore = KeyStore.getInstance("HDImageStore");
        keyStore.load(null, null);
        Certificate cert = keyStore.getCertificate("44-fz");
        Key key = keyStore.getKey("44-fz", "changeit".toCharArray());
        keyStore.setKeyEntry("44-fz", key, "changeit".toCharArray(), new Certificate[]{cert});
        KeyManagerFactory keyManagerFactory = KeyManagerFactory.getInstance(storeAlgorithm);
        keyManagerFactory.init(keyStore, "chngeit".toCharArray());

        KeyStore trustStore = KeyStore.getInstance("jks");
        trustStore.load(new FileInputStream("certs.jks"), "changeit".toCharArray());
        TrustManagerFactory trustManagerFactory = TrustManagerFactory.getInstance("GostX509");
        trustManagerFactory.init(trustStore);
        TrustManager[] trustManagers = trustManagerFactory.getTrustManagers();


        SSLContext sslContext = SSLContexts.custom()
                .loadTrustMaterial(trustStore, new TrustSelfSignedStrategy())
                .loadKeyMaterial(keyStore, tlsPassword, (alias, socket) -> {
                    return tlsHDImageStoreAlias;
                })
                .setProtocol("GostTLS")
                .build();
        *//*SSLContext sslContext = SSLContext.getInstance(contextAlgorithm);
        sslContext.init(keyManagerFactory.getKeyManagers(), trustManagers, null);*//*
        return sslContext;
    }

    public String send(String url, SSLSocketFactory sslSocketFactory) {
        StringBuffer bufferRes;
        String result = "";
        try {
            URL urlGet = new URL(url);
            HttpsURLConnection http = (HttpsURLConnection) urlGet.openConnection();
            http.setConnectTimeout(25000);
            http.setReadTimeout(25000);
            http.setRequestMethod("POST");
            http.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            http.setSSLSocketFactory(sslSocketFactory);
            //http.setHostnameVerifier(new Verifier());
            http.setDoOutput(true);
            http.setDoInput(true);

            OutputStream os = http.getOutputStream();

            StringBuilder pakage = new StringBuilder();
            pakage.append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>");
            pakage.append("<Package xmlns=\"http://www.sberbank.ru/edo/oep/edo-oep-document\">");
            pakage.append("<TypeDocument>PartyCheckRs</TypeDocument>");
            pakage.append("<Document>PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0idXRmLTgiIHN0YW5kYWxvbmU9InllcyI/Pgo8UGFydHlDaGVja1JzIHhtbG5zPSJodHRwOi8vd3d3LnNiZXJiYW5rLnJ1L2Vkby9vZXAvZWRvLW9lcC1wcm9jIj4KICA8TXNnSUQ+NzcwNEM3MDVDNUZFMDg5N0UwNTMzRkZDNTIwQThFNjI8L01zZ0lEPgogIDxNc2dUbT4yMDE4LTA5LTI5VDE3OjU2OjMxPC9Nc2dUbT4KICA8Q29ycmVsYXRpb25JRD40Y2I4ZWM0Y2U1NmE0MjdmOTUwOTRjOGFhNjBhNTJjOTwvQ29ycmVsYXRpb25JRD4KICA8T3BlcmF0b3JOYW1lPkVUUF9SVFM8L09wZXJhdG9yTmFtZT4KICA8QmFua0lEPlJOS0I8L0JhbmtJRD4KICA8SU5OPjUxMTQ5MDY1NzQ8L0lOTj4KICA8S1BQPjg4OTgxMDIwMTwvS1BQPgogIDxPR1JOPjk1Njg4MTM1MTY1MzE8L09HUk4+CiAgPFN0YXR1cz48U3RhdHVzQ29kZT4yPC9TdGF0dXNDb2RlPjxTdGF0dXNEZXNjPtCX0LDQv9GA0L7RgSDQvdC1INCy0YvQv9C+0LvQvdC10L0sINGB0YfQtdGCINC+0YLRgdGD0YLRgdGC0LLRg9C10YI8L1N0YXR1c0Rlc2M+PC9TdGF0dXM+CjwvUGFydHlDaGVja1JzPg==</Document>");
            pakage.append("<Signature>MIAGCSqGSIb3DQEHAqCAMIACAQExDDAKBgYqhQMCAgkFADCABgkqhkiG9w0BBwEAAKCAMIIIATCCB7CgAwIBAgIRAQUgqXrEDNGA6BGvwJa3HA8wCAYGKoUDAgIDMIIBbDEYMBYGBSqFA2QBEg0xMDI3NzAwMDcxNTMwMRowGAYIKoUDA4EDAQESDDAwNzcwNDIxMTIwMTELMAkGA1UEBhMCUlUxGDAWBgNVBAgMDzc3INCc0L7RgdC60LLQsDEVMBMGA1UEBwwM0JzQvtGB0LrQstCwMTkwNwYDVQQJDDDQkdCw0YDRi9C60L7QstGB0LrQuNC5INC/0LXRgC4sINC0LiA0LCDRgdGC0YAuIDIxMDAuBgNVBAsMJ9Cj0LTQvtGB0YLQvtCy0LXRgNGP0Y7RidC40Lkg0YbQtdC90YLRgDFnMGUGA1UECgxe0J7QsdGJ0LXRgdGC0LLQviDRgSDQvtCz0YDQsNC90LjRh9C10L3QvdC+0Lkg0L7RgtCy0LXRgtGB0YLQstC10L3QvdC+0YHRgtGM0Y4gItCi0LDQutGB0LrQvtC8IjEgMB4GA1UEAwwX0J7QntCeICLQotCw0LrRgdC60L7QvCIwHhcNMTgwOTI1MTAyODAwWhcNMTkwOTI1MTAzODAwWjCCATsxGjAYBggqhQMDgQMBARIMMDA3NzAxMTA1NDYwMRgwFgYFKoUDZAESDTEwMjc3MDAzODEyOTAxIzAhBgNVBAoMGtCg0J3QmtCRINCR0JDQndCaICjQn9CQ0J4pMVUwUwYDVQQJDEzQo9Cb0JjQptCQINCd0JDQkdCV0KDQldCW0J3QkNCvINCY0JzQldCd0JggNjAt0JvQldCi0JjQryDQodCh0KHQoCwg0JTQntCcIDM0MSowKAYDVQQHDCHQk9Ce0KDQntCUINCh0JjQnNCk0JXQoNCe0J/QntCb0KwxKTAnBgNVBAgMIDkxINCg0LXRgdC/0YPQsdC70LjQutCwINCa0YDRi9C8MQswCQYDVQQGEwJSVTEjMCEGA1UEAwwa0KDQndCa0JEg0JHQkNCd0JogKNCf0JDQnikwYzAcBgYqhQMCAhMwEgYHKoUDAgIkAAYHKoUDAgIeAQNDAARAWCEC1hJ1u4juAGOZ96B8inyQ9P17wfn3yLt9H7sIZeUkYJroVMmwlJGL0rdYQh82xTXYMHpeaaXtbMP627hEHqOCBFYwggRSMDQGCSsGAQQBgjcVBwQnMCUGHSqFAwICMgEJgdWRAYPDxk+F1ZU0g+ePBoOyB8wYAgEBAgEAMIIBhQYDVR0jBIIBfDCCAXiAFMLYIvy8D/3IrEBi5x/IszCf2ja7oYIBUqSCAU4wggFKMR4wHAYJKoZIhvcNAQkBFg9kaXRAbWluc3Z5YXoucnUxCzAJBgNVBAYTAlJVMRwwGgYDVQQIDBM3NyDQsy4g0JzQvtGB0LrQstCwMRUwEwYDVQQHDAzQnNC+0YHQutCy0LAxPzA9BgNVBAkMNjEyNTM3NSDQsy4g0JzQvtGB0LrQstCwLCDRg9C7LiDQotCy0LXRgNGB0LrQsNGPLCDQtC4gNzEsMCoGA1UECgwj0JzQuNC90LrQvtC80YHQstGP0LfRjCDQoNC+0YHRgdC40LgxGDAWBgUqhQNkARINMTA0NzcwMjAyNjcwMTEaMBgGCCqFAwOBAwEBEgwwMDc3MTA0NzQzNzUxQTA/BgNVBAMMONCT0L7Qu9C+0LLQvdC+0Lkg0YPQtNC+0YHRgtC+0LLQtdGA0Y/RjtGJ0LjQuSDRhtC10L3RgtGAggo9vVUJAAAAAAI8MB0GA1UdDgQWBBQ4cJGaapAK5xB08hsvg3cnTb5fljAOBgNVHQ8BAf8EBAMCA/gwHQYDVR0lBBYwFAYIKwYBBQUHAwIGCCsGAQUFBwMEMB0GA1UdIAQWMBQwCAYGKoUDZHEBMAgGBiqFA2RxAjCCARQGBSqFA2RwBIIBCTCCAQUMKyLQmtGA0LjQv9GC0L7Qn9GA0L4gQ1NQIiAo0LLQtdGA0YHQuNGPIDQuMCkMLCLQmtGA0LjQv9GC0L7Qn9GA0L4g0KPQpiIgKNCy0LXRgNGB0LjRjyAyLjApDFfQodC10YDRgtC40YTQuNC60LDRgiDRgdC+0L7RgtCy0LXRgtGB0YLQstC40Y8g0KHQpC8xMjQtMjg2NCDQvtGCIDIwINC80LDRgNGC0LAgMjAxNiDQsy4MT9Ch0LXRgNGC0LjRhNC40LrQsNGCINGB0L7QvtGC0LLQtdGC0YHRgtCy0LjRjyDQodCkLzEyOC0yOTgzINC+0YIgMTguMTEuMjAxNiDQsy4wIwYFKoUDZG8EGgwYItCa0YDQuNC/0YLQvtCf0YDQviBDU1AiMFIGA1UdHwRLMEkwR6BFoEOGQWh0dHA6Ly9jcmwudGF4Y29tLnJ1L2MyZDgyMmZjYmMwZmZkYzhhYzQwNjJlNzFmYzhiMzMwOWZkYTM2YmIuY3JsMIGSBggrBgEFBQcBAQSBhTCBgjAxBggrBgEFBQcwAYYlaHR0cDovL29jc3AyMC50YXhjb20ucnUvb2NzcC9vY3NwLnNyZjBNBggrBgEFBQcwAoZBaHR0cDovL2NybC50YXhjb20ucnUvYzJkODIyZmNiYzBmZmRjOGFjNDA2MmU3MWZjOGIzMzA5ZmRhMzZiYi5jcnQwCAYGKoUDAgIDA0EAIB7E6gxLoBdaoJ1PvgsTUFoMPov8/lfjA2yfodOPJZnfDSQZGGdYjZHvGJsb5SDfJ7OA6ukzgObsHuaItQwJCQAAMYIEETCCBA0CAQEwggGDMIIBbDEYMBYGBSqFA2QBEg0xMDI3NzAwMDcxNTMwMRowGAYIKoUDA4EDAQESDDAwNzcwNDIxMTIwMTELMAkGA1UEBhMCUlUxGDAWBgNVBAgMDzc3INCc0L7RgdC60LLQsDEVMBMGA1UEBwwM0JzQvtGB0LrQstCwMTkwNwYDVQQJDDDQkdCw0YDRi9C60L7QstGB0LrQuNC5INC/0LXRgC4sINC0LiA0LCDRgdGC0YAuIDIxMDAuBgNVBAsMJ9Cj0LTQvtGB0YLQvtCy0LXRgNGP0Y7RidC40Lkg0YbQtdC90YLRgDFnMGUGA1UECgxe0J7QsdGJ0LXRgdGC0LLQviDRgSDQvtCz0YDQsNC90LjRh9C10L3QvdC+0Lkg0L7RgtCy0LXRgtGB0YLQstC10L3QvdC+0YHRgtGM0Y4gItCi0LDQutGB0LrQvtC8IjEgMB4GA1UEAwwX0J7QntCeICLQotCw0LrRgdC60L7QvCICEQEFIKl6xAzRgOgRr8CWtxwPMAoGBiqFAwICCQUAoIICJzAYBgkqhkiG9w0BCQMxCwYJKoZIhvcNAQcBMC8GCSqGSIb3DQEJBDEiBCCrXAP5lgOHb2E24Dms0Zs8m39qPffLXhw8yvmQ1apGNTCCAdgGCyqGSIb3DQEJEAIvMYIBxzCCAcMwggG/MIIBuzAIBgYqhQMCAgkEIHo3ae54/PrPEm2dmRYAuNFf1TCO6ct3Jm9rKCrLwXOKMIIBizCCAXSkggFwMIIBbDEYMBYGBSqFA2QBEg0xMDI3NzAwMDcxNTMwMRowGAYIKoUDA4EDAQESDDAwNzcwNDIxMTIwMTELMAkGA1UEBhMCUlUxGDAWBgNVBAgMDzc3INCc0L7RgdC60LLQsDEVMBMGA1UEBwwM0JzQvtGB0LrQstCwMTkwNwYDVQQJDDDQkdCw0YDRi9C60L7QstGB0LrQuNC5INC/0LXRgC4sINC0LiA0LCDRgdGC0YAuIDIxMDAuBgNVBAsMJ9Cj0LTQvtGB0YLQvtCy0LXRgNGP0Y7RidC40Lkg0YbQtdC90YLRgDFnMGUGA1UECgxe0J7QsdGJ0LXRgdGC0LLQviDRgSDQvtCz0YDQsNC90LjRh9C10L3QvdC+0Lkg0L7RgtCy0LXRgtGB0YLQstC10L3QvdC+0YHRgtGM0Y4gItCi0LDQutGB0LrQvtC8IjEgMB4GA1UEAwwX0J7QntCeICLQotCw0LrRgdC60L7QvCICEQEFIKl6xAzRgOgRr8CWtxwPMAgGBiqFAwICEwRADwCLWfUwegoYGD5n6/8RoMm71xyiHn4JyIQru/dyEOmVodaWwN2+vpD6yCOnvDhPoVwmdtUyyk96RZnR/FrdAQAAAAAAAA==</Signature>");
            pakage.append("</Package>");

            os.write(pakage.toString().getBytes("UTF-8"));

            http.connect();


            InputStream in = http.getInputStream();
            BufferedReader read = new BufferedReader(new InputStreamReader(in, "UTF-8"));
            String valueString = null;
            bufferRes = new StringBuffer();
            while ((valueString = read.readLine()) != null) {
                bufferRes.append(valueString);
            }
            result = bufferRes.toString();
            in.close();
            if (http != null) {
                http.disconnect();
            }
        } catch (Exception e) {
            result = e.getMessage();
        }
        return result;
    }*/
}