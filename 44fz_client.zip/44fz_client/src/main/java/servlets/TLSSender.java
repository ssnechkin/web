package servlets;

import org.apache.http.conn.ssl.TrustSelfSignedStrategy;
import org.apache.http.ssl.SSLContexts;

import javax.net.ssl.*;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.net.URL;
import java.security.Key;
import java.security.KeyPair;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.cert.Certificate;
import java.security.cert.X509Certificate;

public class TLSSender extends HttpServlet {
    @Override
    public void init() {
        // System.out.println("init");
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String result = "server null";

        try {
            result = send("https://stage-banki.tektorg.ru:10443/callback", getSSLContext().getSocketFactory());
        } catch (Exception e) {
            e.printStackTrace();
        }

        response.setContentType("text/html;charset=utf-8");
        response.setStatus(HttpServletResponse.SC_OK);
        response.getWriter().println("<h1>" + result + "</h1>");
    }

    public SSLContext getSSLContext() throws Exception {
        String storeAlgorithm = "GostX509";
        String contextAlgorithm = "TLSv1.2"; //Provider.ALGORITHM
        char[] tlsPassword = "changeit".toCharArray();
        String tlsHDImageStoreAlias = "44-fz";

        KeyStore keyStore = KeyStore.getInstance("HDImageStore");
        keyStore.load(null, null);
        Certificate cert = keyStore.getCertificate("44-fz");
        Key key = keyStore.getKey("44-fz", "changeit".toCharArray());
        keyStore.setKeyEntry("44-fz", key, "changeit".toCharArray(), new Certificate[]{cert});
        KeyManagerFactory keyManagerFactory = KeyManagerFactory.getInstance(storeAlgorithm);
        keyManagerFactory.init(keyStore, "chngeit".toCharArray());

        KeyStore trustStore = KeyStore.getInstance("jks");
        trustStore.load(new FileInputStream("certs.jks"), "changeit".toCharArray());
        TrustManagerFactory trustManagerFactory = TrustManagerFactory.getInstance(storeAlgorithm);
        trustManagerFactory.init(trustStore);

       /* sslContext = SSLContexts.custom()
                .loadTrustMaterial(trustStore, new TrustSelfSignedStrategy())
                .loadKeyMaterial(keyStore, tlsPassword, (alias, socket) -> {
                    return tlsHDImageStoreAlias;
                })
                .build();*/
        SSLContext sslContext = SSLContext.getInstance(contextAlgorithm);
        sslContext.init(keyManagerFactory.getKeyManagers(), trustManagerFactory.getTrustManagers(), null);

        return sslContext;
    }

    public String send(String url, SSLSocketFactory sslSocketFactory) throws IOException {
        StringBuffer bufferRes;

        URL urlGet = new URL(url);
        HttpsURLConnection http = (HttpsURLConnection) urlGet.openConnection();
        http.setConnectTimeout(25000);
        http.setReadTimeout(25000);
        http.setRequestMethod("POST");
        http.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
        http.setSSLSocketFactory(sslSocketFactory);
        //http.setHostnameVerifier(new Verifier());
        http.setDoOutput(true);
        http.setDoInput(true);
        http.connect();

        InputStream in = http.getInputStream();
        BufferedReader read = new BufferedReader(new InputStreamReader(in, "UTF-8"));
        String valueString = null;
        bufferRes = new StringBuffer();
        while ((valueString = read.readLine()) != null) {
            bufferRes.append(valueString);
        }
        in.close();
        if (http != null) {
            http.disconnect();
        }
        return bufferRes.toString();
    }
}
