package utils;

import javax.net.ssl.*;
import java.io.*;
import java.net.URL;
import java.security.Key;
import java.security.KeyStore;
import java.util.HashMap;
import java.util.Map;

/**
 * Класс для отправки сообщений по TLS-соединению.
 *
 * @author nechkin.sergei.sergeevich
 */
public class GostTLS {
    private String sslProtocol = "GostTLS";

    private String keyStoreType = "HDImageStore";
    private String keyAlias;
    private char[] keyStorePasword;
    private String keyStorePath = null;
    private String keyManagerAlgorithm = "GostX509";

    private String trustStoreType = "JKS";
    private char[] trustStorePasword;
    private String trustStorePath;
    private String trustManagerAlgorithm = "GostX509";

    private SSLContext sslContext;
    private SSLSocketFactory sslSocketFactory;

    private Integer connectTimeout = 25000;
    private Integer readTimeout = 25000;
    private String requestMethod = "POST";
    private String inputStreamCharet = "UTF-8";
    private HashMap<String, String> requestPropertys = new HashMap<>();
    private boolean doOutput = true;
    private boolean doInput = true;

    public GostTLS(String keyAlias, char[] keyStorePasword, String trustStorePath, char[] trustStorePasword) throws Exception {
        this.keyAlias = keyAlias;
        this.trustStorePath = trustStorePath;
        this.keyStorePasword = keyStorePasword;
        this.trustStorePasword = trustStorePasword;
        requestPropertys.put("Content-Type", "application/x-www-form-urlencoded");
        init();
    }

    /**
     * Загрузить хранилища
     *
     * @throws Exception
     */
    public void init() throws Exception {
        System.setProperty("com.sun.security.enableCRLDP", "true");
        System.setProperty("com.ibm.security.enableCRLDP", "true");

        if (keyStorePasword != null && keyStorePasword.length == 0)
            this.keyStorePasword = null;

        if (keyStorePath != null && keyStorePath.length() == 0)
            this.keyStorePath = null;

        if (trustStorePasword != null && trustStorePasword.length == 0)
            this.trustStorePasword = null;

        if (trustStorePath != null && trustStorePath.length() == 0)
            this.trustStorePath = null;

        sslContext = getTLSContext();
        sslSocketFactory = sslContext.getSocketFactory();
    }

    /**
     * Возвращает контекст соединения. Загружает в память ключи и сертификаты.
     *
     * @return контекст соединения
     * @throws Exception
     */
    private SSLContext getTLSContext() throws Exception {

        // Задать хранилище ключей с сертификатами
        KeyStore keyStore = KeyStore.getInstance(keyStoreType);
        if (keyStorePath == null) {
            keyStore.load(null, null);
        } else {
            keyStore.load(new FileInputStream(keyStorePath), keyStorePasword);
        }
        Key key = keyStore.getKey(keyAlias, keyStorePasword);
        keyStore.setKeyEntry(keyAlias, key, keyStorePasword, keyStore.getCertificateChain(keyAlias));
        KeyManagerFactory keyManagerFactory = KeyManagerFactory.getInstance(keyManagerAlgorithm);
        keyManagerFactory.init(keyStore, keyStorePasword);

        //Задать доверенное хранилище сертификатов
        //keytool.exe -import -trustcacerts -keystore certs_store.jks -alias certificat_name_alias -file Сертификат.cer
        KeyStore trustStore = KeyStore.getInstance(trustStoreType);
        if (trustStore == null) {
            trustStore.load(null, null);
        } else {
            trustStore.load(new FileInputStream(trustStorePath), trustStorePasword);
        }
        TrustManagerFactory trustManagerFactory = TrustManagerFactory.getInstance(trustManagerAlgorithm);
        trustManagerFactory.init(trustStore);
        TrustManager[] trustManagers = trustManagerFactory.getTrustManagers();

        //Получить экземпляр контекста
        SSLContext sslContext = SSLContext.getInstance(sslProtocol);
        sslContext.init(keyManagerFactory.getKeyManagers(), trustManagers, null);

        return sslContext;
    }

    /**
     * Отправить сообщение
     *
     * @param url     url-адрес
     * @param message сообщение
     * @return ответ сервера
     * @throws IOException
     */
    public String sendMessage(String url, byte[] message) throws IOException {
        StringBuffer bufferRes;
        String valueString;
        HttpsURLConnection http;
        InputStream inputStream;
        BufferedReader bufferedReader;

        http = (HttpsURLConnection) new URL(url).openConnection();
        http.setConnectTimeout(connectTimeout);
        http.setReadTimeout(readTimeout);
        http.setRequestMethod(requestMethod);
        http.setSSLSocketFactory(sslSocketFactory);
        http.setDoOutput(doOutput);
        http.setDoInput(doInput);
        for (Map.Entry<String, String> entry : requestPropertys.entrySet())
            http.setRequestProperty(entry.getKey(), entry.getValue());
        http.getOutputStream().write(message);
        http.connect();

        inputStream = http.getInputStream();
        bufferedReader = new BufferedReader(new InputStreamReader(inputStream, inputStreamCharet));
        bufferRes = new StringBuffer();

        while ((valueString = bufferedReader.readLine()) != null)
            bufferRes.append(valueString);

        http.disconnect();
        inputStream.close();

        return bufferRes.toString();
    }

    public String getSslProtocol() {
        return sslProtocol;
    }

    public void setSslProtocol(String sslProtocol) {
        this.sslProtocol = sslProtocol;
    }

    public String getKeyStoreType() {
        return keyStoreType;
    }

    public void setKeyStoreType(String keyStoreType) {
        this.keyStoreType = keyStoreType;
    }

    public String getKeyAlias() {
        return keyAlias;
    }

    public void setKeyAlias(String keyAlias) {
        this.keyAlias = keyAlias;
    }

    public char[] getKeyStorePasword() {
        return keyStorePasword;
    }

    public void setKeyStorePasword(char[] keyStorePasword) {
        this.keyStorePasword = keyStorePasword;
    }

    public String getKeyStorePath() {
        return keyStorePath;
    }

    public void setKeyStorePath(String keyStorePath) {
        this.keyStorePath = keyStorePath;
    }

    public String getKeyManagerAlgorithm() {
        return keyManagerAlgorithm;
    }

    public void setKeyManagerAlgorithm(String keyManagerAlgorithm) {
        this.keyManagerAlgorithm = keyManagerAlgorithm;
    }

    public String getTrustStoreType() {
        return trustStoreType;
    }

    public void setTrustStoreType(String trustStoreType) {
        this.trustStoreType = trustStoreType;
    }

    public char[] getTrustStorePasword() {
        return trustStorePasword;
    }

    public void setTrustStorePasword(char[] trustStorePasword) {
        this.trustStorePasword = trustStorePasword;
    }

    public String getTrustStorePath() {
        return trustStorePath;
    }

    public void setTrustStorePath(String trustStorePath) {
        this.trustStorePath = trustStorePath;
    }

    public String getTrustManagerAlgorithm() {
        return trustManagerAlgorithm;
    }

    public void setTrustManagerAlgorithm(String trustManagerAlgorithm) {
        this.trustManagerAlgorithm = trustManagerAlgorithm;
    }

    public SSLContext getSslContext() {
        return sslContext;
    }

    public void setSslContext(SSLContext sslContext) {
        this.sslContext = sslContext;
    }

    public SSLSocketFactory getSslSocketFactory() {
        return sslSocketFactory;
    }

    public void setSslSocketFactory(SSLSocketFactory sslSocketFactory) {
        this.sslSocketFactory = sslSocketFactory;
    }

    public Integer getConnectTimeout() {
        return connectTimeout;
    }

    public void setConnectTimeout(Integer connectTimeout) {
        this.connectTimeout = connectTimeout;
    }

    public Integer getReadTimeout() {
        return readTimeout;
    }

    public void setReadTimeout(Integer readTimeout) {
        this.readTimeout = readTimeout;
    }

    public String getRequestMethod() {
        return requestMethod;
    }

    public void setRequestMethod(String requestMethod) {
        this.requestMethod = requestMethod;
    }

    public String getInputStreamCharet() {
        return inputStreamCharet;
    }

    public void setInputStreamCharet(String inputStreamCharet) {
        this.inputStreamCharet = inputStreamCharet;
    }

    public HashMap<String, String> getRequestPropertys() {
        return requestPropertys;
    }

    public void setRequestPropertys(HashMap<String, String> requestPropertys) {
        this.requestPropertys = requestPropertys;
    }

    public boolean isDoOutput() {
        return doOutput;
    }

    public void setDoOutput(boolean doOutput) {
        this.doOutput = doOutput;
    }

    public boolean isDoInput() {
        return doInput;
    }

    public void setDoInput(boolean doInput) {
        this.doInput = doInput;
    }
}
