import org.eclipse.jetty.http.HttpVersion;
import org.eclipse.jetty.server.*;
import org.eclipse.jetty.servlet.ServletContextHandler;
import org.eclipse.jetty.servlet.ServletHolder;
import org.eclipse.jetty.util.ssl.SslContextFactory;
import handlers.HelloHandler;
import servlets.TLSSender;

import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManagerFactory;
import java.io.File;
import java.io.FileInputStream;
import java.security.Key;
import java.security.KeyStore;
import java.security.cert.Certificate;

public class Main {
    public static void main(String[] args) {
        serverStart();
    }

    private static void serverStart() {
        ServletContextHandler context = new ServletContextHandler(ServletContextHandler.SESSIONS);
        context.addServlet(new ServletHolder(new TLSSender()), "/");

        Server server = new Server(8080);
        server.setHandler(context);

        try {
            server.start();
            System.out.println("Server started");
            server.join();
        } catch (Throwable t) {
            System.out.println("Server error: " + t.getMessage());
            t.printStackTrace(System.err);
        }
    }

    public void tlsServerStart() {
        String jettyDistKeystore = "../../jetty-distribution/target/distribution/demo-base/etc/keystore";
        String keystorePath = System.getProperty("example.keystore", jettyDistKeystore);

        File keystoreFile = new File(keystorePath);
        if (!keystoreFile.exists()) {
            keystorePath = "jetty-distribution/target/distribution/demo-base/etc/keystore";
            keystoreFile = new File(keystorePath);
        }

        Server server = new Server();

        HttpConfiguration http_config = new HttpConfiguration();
        http_config.setSecureScheme("https");
        http_config.setSecurePort(8443);
        http_config.setOutputBufferSize(32768);

        ServerConnector http = new ServerConnector(server,
                new HttpConnectionFactory(http_config));
        http.setPort(8080);
        http.setIdleTimeout(30000);

        SslContextFactory sslContextFactory = new SslContextFactory();
        sslContextFactory.setKeyStorePath(keystoreFile.getAbsolutePath());
        sslContextFactory.setKeyStorePassword("OBF:1vny1zlo1x8e1vnw1vn61x8g1zlu1vn4");
        sslContextFactory.setKeyManagerPassword("OBF:1u2u1wml1z7s1z7a1wnl1u2g");

        HttpConfiguration https_config = new HttpConfiguration(http_config);
        SecureRequestCustomizer src = new SecureRequestCustomizer();
        src.setStsMaxAge(2000);
        src.setStsIncludeSubDomains(true);
        https_config.addCustomizer(src);

        ServerConnector https = new ServerConnector(server,
                new SslConnectionFactory(sslContextFactory, HttpVersion.HTTP_1_1.asString()),
                new HttpConnectionFactory(https_config));
        https.setPort(8443);
        https.setIdleTimeout(500000);

        server.setConnectors(new Connector[]{http, https});


        server.setHandler(new HelloHandler());

        try {
            server.start();
            server.join();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public SSLContext getSSLContext() throws Exception {
        String storeAlgorithm = "GostX509";
        String contextAlgorithm = "TLSv1.2"; //Provider.ALGORITHM
        char[] tlsPassword = "changeit".toCharArray();
        String tlsHDImageStoreAlias = "44-fz";

        KeyStore keyStore = KeyStore.getInstance("HDImageStore");
        keyStore.load(null, null);
        Certificate cert = keyStore.getCertificate("44-fz");
        Key key = keyStore.getKey("44-fz", "changeit".toCharArray());
        keyStore.setKeyEntry("44-fz", key, "changeit".toCharArray(), new Certificate[]{cert});
        KeyManagerFactory keyManagerFactory = KeyManagerFactory.getInstance(storeAlgorithm);
        keyManagerFactory.init(keyStore, "chngeit".toCharArray());

        KeyStore trustStore = KeyStore.getInstance("jks");
        trustStore.load(new FileInputStream("certs.jks"), "changeit".toCharArray());
        TrustManagerFactory trustManagerFactory = TrustManagerFactory.getInstance(storeAlgorithm);
        trustManagerFactory.init(trustStore);

       /* sslContext = SSLContexts.custom()
                .loadTrustMaterial(trustStore, new TrustSelfSignedStrategy())
                .loadKeyMaterial(keyStore, tlsPassword, (alias, socket) -> {
                    return tlsHDImageStoreAlias;
                })
                .build();*/
        SSLContext sslContext = SSLContext.getInstance(contextAlgorithm);
        sslContext.init(keyManagerFactory.getKeyManagers(), trustManagerFactory.getTrustManagers(), null);

        return sslContext;
    }
}
